#!/bin/bash
#cd $SCRATCH/data/fspPos
#$LUM/fdtd-solutions -trust-script -run ~/bin/getData.lsf
~/bin/lsfmaker.sh
