#!/bin/bash
cd $SCRATCH/data/binary/
$LUM/fdtd-solutions -trust-script -run ~/bin/createLsf.lsf

